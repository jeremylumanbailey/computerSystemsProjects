// Include Files
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// Project Includes
#include "lab3header.h"

// Function Implementations

int reverse_number(int num)
{
}


int reverse_number_do_while(int num)
{
}


int even_odd(int num)
{
}


int prime(int num)
{
}

