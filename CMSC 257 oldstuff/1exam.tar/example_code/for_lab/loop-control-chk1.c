// Include Files
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

// Project Includes
#include "lab3header.h"


int main(int argc, char *argv[]) {
	
//write your code	
	
	
	return(0);
}
